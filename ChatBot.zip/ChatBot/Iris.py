from flask import Flask, render_template, request, jsonify
import pyodbc

# Establecer la conexión a la base de datos
server = 'ROYERCZLAP\SQLEXPRESS;Database=BDIris'
database = 'BDIris'
conn = pyodbc.connect('DRIVER={SQL Server};SERVER='+server+';DATABASE='+database)
cursor = conn.cursor()

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/consultar', methods=['POST'])
def consultar():
    consulta = request.form['consulta']
def procesar_consulta_con_chatbot(consulta):
    # Aquí puedes implementar la lógica para procesar la consulta y generar la respuesta del chatbot
    # Por ejemplo, una lógica simple de devolución de respuesta podría ser:
    if consulta.lower() == 'hola':
        return '¡Hola! ¿En qué puedo ayudarte?'
    else:
        return 'Lo siento, no entendí la consulta.'    
    # Lógica para procesar la consulta con el chatbot y obtener una respuesta
    respuesta = procesar_consulta_con_chatbot(consulta)
    
    return jsonify({'consulta': consulta, 'respuesta': respuesta})

if __name__ == '__main__':
    app.run()
