document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("consulta-form");
    const input = document.getElementById("consulta");
    const chatbox = document.getElementById("chatbox");

    form.addEventListener("submit", function(event) {
        event.preventDefault();
        const message = input.value;
        if (message.trim() === "") return;

        // Añadir mensaje del usuario al chatbox
        addMessageToChatbox(message, 'user');

        // Enviar mensaje al servidor
        fetch("/get_response", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            // Añadir respuesta del chatbot al chatbox
            addMessageToChatbox(data.response, 'bot');
        });

        // Limpiar el campo de entrada
        input.value = "";
    });

    function addMessageToChatbox(message, type) {
        const messageElement = document.createElement("div");
        messageElement.textContent = message;
        messageElement.classList.add("message", type);
        chatbox.appendChild(messageElement);
        chatbox.scrollTop = chatbox.scrollHeight;
    }
});