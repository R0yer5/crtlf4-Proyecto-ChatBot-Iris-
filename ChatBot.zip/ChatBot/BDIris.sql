    USE master
go 
-- Comando condicional para la base de datos

IF	DB_ID ('BdIris') IS NOT NULL
DROP DATABASE BdIris
GO
-- Crear la base de datos
CREATE DATABASE BdIris;
GO

-- Usar la base de datos
USE BdIris;
GO
-- Condicionales para las tablas 
if OBJECT_ID('TPersona') is not null
drop table TDocente
go

if OBJECT_ID('TAsignatura') is not null
drop table TAsignatura
go

if OBJECT_ID('THorario') is not null
drop table THorario
go


-- Crear la tabla Persona
CREATE TABLE TDocente (
    dni VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    correoElectronico VARCHAR(100),
    nroCelular VARCHAR(15)
);
GO

-- Crear la tabla Asignatura
CREATE TABLE TAsignatura (
    NRC INT PRIMARY KEY,
    NombreAsignatura VARCHAR(100),
    DniProfesor varCHAR(20),
    FOREIGN KEY (DniProfesor) REFERENCES TDocente(dni)
);
GO

CREATE TABLE THorario (
    NRC INT,
    dia VARCHAR(15),
    hora varchar(100),
	Aula varchar(20),
	FOREIGN KEY (NRC) REFERENCES TAsignatura(NRC)
);


use BdIris
go 
INSERT INTO TDocente(dni, nombre, apellido, correoElectronico, nroCelular) 
VALUES 
('23983332','HUGO','ESPETIA HUAMANGA','23983332@CONTINENTAL.EDU.PE','999999999');

INSERT INTO TAsignatura (NRC, NombreAsignatura, DniProfesor) 
VALUES 
(12860,'CONSTRUCCION DE SOFTWARE','23983332'),
(12861,'CONSTRUCCION DE SOFTWARE','23983332')


INSERT INTO THorario (NRC, dia,hora,aula)
VALUES
(12861,'MIERCOLES','14:00 pm - 15:30 pm','A306'),
(12860,'JUEVES','14:00 pm - 16:30 pm','A801');




select * from TDocente
select * from TAsignatura
SELECT * FROM THorario